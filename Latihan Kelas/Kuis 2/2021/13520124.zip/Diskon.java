interface Diskon{
    public double diskon(int hargaNormal)
;}